package pt.zoediag;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.BluetoothSocket;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ConcurrentLinkedQueue;

@SuppressLint("MissingPermission")
@SuppressWarnings("deprecation")
public class MainActivity extends Activity {

    private static final UUID SPP = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private static final UUID CCCD = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");

    private WebView web;
    private BluetoothAdapter adapter;
    private BluetoothLeScanner scanner;
    private final Handler ui = new Handler(Looper.getMainLooper());

    private volatile BluetoothGatt gatt;
    private volatile BluetoothGattCharacteristic wChar;
    private BluetoothGattCharacteristic pendingW;
    private BluetoothGattService pendingSvc;
    private BluetoothGattCharacteristic pendingN;
    private final ConcurrentLinkedQueue<byte[]> queue = new ConcurrentLinkedQueue<>();
    private volatile boolean writing = false;

    private volatile BluetoothSocket socket;
    private volatile OutputStream out;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(), "AndroidBle");
        setContentView(web);
        BluetoothManager bm = (BluetoothManager) getSystemService(BLUETOOTH_SERVICE);
        adapter = bm != null ? bm.getAdapter() : null;
        askPermissions();
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        closeAll();
        super.onDestroy();
    }

    private String[] neededPerms() {
        if (Build.VERSION.SDK_INT >= 31)
            return new String[]{Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT};
        return new String[]{Manifest.permission.ACCESS_FINE_LOCATION};
    }

    private boolean hasPerms() {
        for (String p : neededPerms())
            if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) return false;
        return true;
    }

    private void askPermissions() {
        List<String> need = new ArrayList<>();
        for (String p : neededPerms())
            if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) need.add(p);
        if (!need.isEmpty()) requestPermissions(need.toArray(new String[0]), 1);
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        js("onPerms", hasPerms() ? "ok" : "negado");
    }

    /** Chama window.__ble.<fn>(args...) na página. */
    private void js(String fn, String... args) {
        StringBuilder sb = new StringBuilder("window.__ble&&window.__ble.").append(fn)
                .append("&&window.__ble.").append(fn).append("(");
        for (int i = 0; i < args.length; i++) {
            if (i > 0) sb.append(',');
            sb.append(JSONObject.quote(args[i]));
        }
        sb.append(");");
        final String code = sb.toString();
        ui.post(() -> { if (web != null) web.evaluateJavascript(code, null); });
    }

    private void closeAll() {
        queue.clear();
        writing = false;
        BluetoothGatt g = gatt;
        gatt = null;
        wChar = null;
        if (g != null) {
            try { g.disconnect(); } catch (Exception ignored) { }
            try { g.close(); } catch (Exception ignored) { }
        }
        BluetoothSocket sk = socket;
        socket = null;
        out = null;
        if (sk != null) {
            try { sk.close(); } catch (Exception ignored) { }
        }
    }

    // ---------- pesquisa BLE ----------
    private final ScanCallback scanCb = new ScanCallback() {
        @Override
        public void onScanResult(int type, ScanResult r) {
            try {
                BluetoothDevice d = r.getDevice();
                String n = null;
                try { n = d.getName(); } catch (Exception ignored) { }
                if (n == null && r.getScanRecord() != null) n = r.getScanRecord().getDeviceName();
                JSONObject o = new JSONObject();
                o.put("name", n == null ? "" : n);
                o.put("address", d.getAddress());
                o.put("rssi", r.getRssi());
                o.put("type", "ble");
                js("onDevice", o.toString());
            } catch (Exception ignored) { }
        }

        @Override
        public void onScanFailed(int errorCode) {
            js("onError", "A pesquisa Bluetooth falhou (código " + errorCode + "). Desliga e volta a ligar o Bluetooth.");
        }
    };

    // ---------- GATT ----------
    private final BluetoothGattCallback gattCb = new BluetoothGattCallback() {
        @Override
        public void onConnectionStateChange(BluetoothGatt g, int status, int newState) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                js("onStep", "ok", "Ligação BLE estabelecida.");
                js("onStep", "run", "A procurar o canal de comunicação do adaptador…");
                ui.postDelayed(g::discoverServices, 300);
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                boolean wasReady = wChar != null && g == gatt;
                if (g == gatt) { gatt = null; wChar = null; }
                try { g.close(); } catch (Exception ignored) { }
                if (wasReady) js("onGone");
                else js("onError", "O dispositivo recusou ou perdeu a ligação BLE (estado " + status + "). Carrega no botão \"Connect\" do vLinker e tenta outra vez.");
            }
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt g, int status) {
            BluetoothGattCharacteristic n = null, w = null;
            BluetoothGattService found = null;
            for (BluetoothGattService s : g.getServices()) {
                String su = s.getUuid().toString();
                if (su.startsWith("00001800") || su.startsWith("00001801") || su.startsWith("0000180a")) continue;
                BluetoothGattCharacteristic nn = null, ww = null;
                for (BluetoothGattCharacteristic c : s.getCharacteristics()) {
                    int p = c.getProperties();
                    if (nn == null && (p & (BluetoothGattCharacteristic.PROPERTY_NOTIFY | BluetoothGattCharacteristic.PROPERTY_INDICATE)) != 0) nn = c;
                    if (ww == null && (p & (BluetoothGattCharacteristic.PROPERTY_WRITE | BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE)) != 0) ww = c;
                }
                if (nn != null && ww != null) { n = nn; w = ww; found = s; break; }
            }
            if (found == null) {
                js("onError", "Este dispositivo não tem o canal de comunicação de um adaptador OBD. Se é o vLinker, experimenta emparelhá-lo nas definições do Android e usar Bluetooth clássico.");
                g.disconnect();
                return;
            }
            pendingW = w; pendingN = n; pendingSvc = found;
            g.setCharacteristicNotification(n, true);
            BluetoothGattDescriptor dsc = n.getDescriptor(CCCD);
            if (dsc != null) {
                boolean notify = (n.getProperties() & BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0;
                dsc.setValue(notify ? BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE : BluetoothGattDescriptor.ENABLE_INDICATION_VALUE);
                if (!g.writeDescriptor(dsc)) ready(g);
            } else {
                ready(g);
            }
        }

        @Override
        public void onDescriptorWrite(BluetoothGatt g, BluetoothGattDescriptor d, int status) {
            ready(g);
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic c) {
            byte[] v = c.getValue();
            if (v != null && v.length > 0) js("onData", new String(v, StandardCharsets.ISO_8859_1));
        }

        @Override
        public void onCharacteristicWrite(BluetoothGatt g, BluetoothGattCharacteristic c, int status) {
            writing = false;
            pump();
        }
    };

    private void ready(BluetoothGatt g) {
        if (wChar != null) return;
        wChar = pendingW;
        try {
            JSONObject o = new JSONObject();
            String name = null;
            try { name = g.getDevice().getName(); } catch (Exception ignored) { }
            o.put("name", name == null ? "(sem nome)" : name);
            o.put("service", pendingSvc.getUuid().toString());
            o.put("write", pendingW.getUuid().toString());
            o.put("notify", pendingN.getUuid().toString());
            js("onConnected", o.toString());
        } catch (Exception e) {
            js("onError", "Erro interno: " + e.getMessage());
        }
        pump();
    }

    private synchronized void pump() {
        BluetoothGatt g = gatt;
        BluetoothGattCharacteristic c = wChar;
        if (writing || g == null || c == null) return;
        byte[] b = queue.peek();
        if (b == null) return;
        boolean noResp = (c.getProperties() & BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0;
        c.setWriteType(noResp ? BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE : BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
        c.setValue(b);
        writing = true;
        if (g.writeCharacteristic(c)) {
            queue.poll();
        } else {
            writing = false;
            ui.postDelayed(this::pump, 20);
        }
    }

    // ---------- ponte para a página ----------
    class Bridge {
        @JavascriptInterface
        public String status() {
            if (adapter == null) return "sem-bt";
            if (!hasPerms()) return "sem-permissao";
            if (!adapter.isEnabled()) return "desligado";
            return "ok";
        }

        @JavascriptInterface
        public void requestPerms() {
            ui.post(MainActivity.this::askPermissions);
        }

        @JavascriptInterface
        public String bonded() {
            JSONArray a = new JSONArray();
            try {
                for (BluetoothDevice d : adapter.getBondedDevices()) {
                    JSONObject o = new JSONObject();
                    String n = d.getName();
                    o.put("name", n == null ? "" : n);
                    o.put("address", d.getAddress());
                    o.put("type", "classic");
                    a.put(o);
                }
            } catch (Exception ignored) { }
            return a.toString();
        }

        @JavascriptInterface
        public void startScan() {
            ui.post(() -> {
                try {
                    scanner = adapter.getBluetoothLeScanner();
                    if (scanner == null) { js("onError", "O Bluetooth está desligado."); return; }
                    scanner.startScan(scanCb);
                } catch (Exception e) {
                    js("onError", "Não foi possível procurar dispositivos: " + e.getMessage());
                }
            });
        }

        @JavascriptInterface
        public void stopScan() {
            ui.post(() -> {
                try { if (scanner != null) scanner.stopScan(scanCb); } catch (Exception ignored) { }
            });
        }

        @JavascriptInterface
        public void connect(String address, String type) {
            closeAll();
            final BluetoothDevice d;
            try {
                d = adapter.getRemoteDevice(address);
            } catch (Exception e) {
                js("onError", "Endereço inválido: " + address);
                return;
            }
            if ("classic".equals(type)) {
                new Thread(() -> {
                    BluetoothSocket sk = null;
                    boolean linked = false;
                    try {
                        js("onStep", "run", "A abrir ligação por Bluetooth clássico…");
                        try { adapter.cancelDiscovery(); } catch (Exception ignored) { }
                        sk = d.createRfcommSocketToServiceRecord(SPP);
                        sk.connect();
                        linked = true;
                        socket = sk;
                        out = sk.getOutputStream();
                        InputStream in = sk.getInputStream();
                        js("onStep", "ok", "Ligação Bluetooth clássico estabelecida.");
                        JSONObject o = new JSONObject();
                        String n = d.getName();
                        o.put("name", n == null ? "(sem nome)" : n);
                        o.put("service", "SPP (Bluetooth clássico)");
                        o.put("write", "RFCOMM");
                        o.put("notify", "RFCOMM");
                        js("onConnected", o.toString());
                        byte[] buf = new byte[1024];
                        int len;
                        while ((len = in.read(buf)) > 0) {
                            js("onData", new String(buf, 0, len, StandardCharsets.ISO_8859_1));
                        }
                    } catch (Exception e) {
                        if (!linked) js("onError", "Não foi possível ligar por Bluetooth clássico. Confirma que o vLinker está emparelhado e que nenhuma outra app está ligada a ele.");
                    }
                    if (linked && socket == sk) { socket = null; out = null; js("onGone"); }
                    try { if (sk != null) sk.close(); } catch (Exception ignored) { }
                }).start();
            } else {
                js("onStep", "run", "A ligar por BLE a " + address + "…");
                ui.post(() -> {
                    try {
                        gatt = d.connectGatt(MainActivity.this, false, gattCb, BluetoothDevice.TRANSPORT_LE);
                    } catch (Exception e) {
                        js("onError", "Não foi possível iniciar a ligação BLE: " + e.getMessage());
                    }
                });
            }
        }

        @JavascriptInterface
        public void write(String s) {
            byte[] b = s.getBytes(StandardCharsets.ISO_8859_1);
            OutputStream o = out;
            if (o != null) {
                try { o.write(b); o.flush(); } catch (Exception e) { js("onGone"); }
                return;
            }
            for (int i = 0; i < b.length; i += 20)
                queue.add(Arrays.copyOfRange(b, i, Math.min(b.length, i + 20)));
            pump();
        }

        @JavascriptInterface
        public void disconnect() {
            closeAll();
        }
    }
}
